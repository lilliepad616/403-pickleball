from django.contrib import admin
from .models import Court

# Register your models here.
admin.site.register(Court)